# 网络守护者 (Network Defender)

## 项目简介
《网络守护者》是一款融合网络自动化概念的塔防游戏。玩家扮演网络安全工程师，通过部署各种网络防御设施来保护核心服务器免受病毒、黑客和恶意软件的攻击。

## 游戏特色
- **网络主题**：所有游戏元素都基于真实的网络概念（IP地址、端口、防火墙、加密等）
- **自动化机制**：包含自动修复、自动升级等网络自动化功能
- **操作简单**：鼠标点击即可布置防御塔，键盘快捷键释放技能
- **老少皆宜**：卡通风格画面，难度循序渐进

## 技术栈
- Python 3.13.5
- Pygame 2.6.0
- PyCharm 2024.1.6

## 安装运行
```bash
pip install pygame
python main.py
```

## 操作说明
- **鼠标左键**：选择并放置防御塔
- **鼠标右键**：取消选择
- **数字键 1-5**：快速选择防御塔类型
- **空格键**：暂停/继续游戏
- **ESC键**：返回菜单

## 项目结构
```
network_defender/
├── main.py              # 游戏入口
├── config.py            # 游戏配置
├── game_engine.py       # 游戏引擎
├── map_system.py        # 地图系统
├── tower_system.py      # 防御塔系统
├── enemy_system.py      # 敌人系统
├── ui_system.py         # UI系统
├── effect_system.py     # 特效系统
├── asset_manager.py     # 资源管理
└── README.md            # 项目说明
```
